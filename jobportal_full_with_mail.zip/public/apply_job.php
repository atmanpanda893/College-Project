<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth/csrf.php';
if (!isset($_SESSION['candidate_id'])) { header('Location: login.php'); exit; }
$id = intval($_GET['id']??0);
$stmt = $pdo->prepare('SELECT * FROM jobs WHERE id=?'); $stmt->execute([$id]); $job = $stmt->fetch();
if (!$job) die('Job not found');
$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_check();
  $cover = trim($_POST['cover_letter'] ?? '');
  $resume_path = null;
  if (!empty($_FILES['resume']['name'])) {
    $u = __DIR__ . '/../uploads';
    if (!is_dir($u)) mkdir($u,0777,true);
    $name = time().'_'.basename($_FILES['resume']['name']);
    move_uploaded_file($_FILES['resume']['tmp_name'],$u.'/'.$name);
    $resume_path = 'uploads/'.$name;
  }
  $app_uid = 'APP'.strtoupper(bin2hex(random_bytes(4)));
  $stmt = $pdo->prepare('INSERT INTO applications (application_uid,candidate_id,job_id,cover_letter,resume_path,applied_at,applied_ip) VALUES (?,?,?,?,?,NOW(),?)');
  $stmt->execute([$app_uid,$_SESSION['candidate_id'],$id,$cover,$resume_path,$_SERVER['REMOTE_ADDR']]);
  $msg='Application submitted. Your UID: '.$app_uid;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Apply</title><link rel="stylesheet" href="css/style.css"></head><body>
<?php include __DIR__ . '/partials/header.php'; ?>
<div class="container">
  <div class="card fade-in" style="max-width:720px;margin:auto">
    <h2>Apply for: <?php echo htmlspecialchars($job['title']); ?></h2>
    <?php if($msg): ?><div style="color:lightgreen"><?php echo $msg; ?></div><?php endif; ?>
    <form method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <label class="small">Cover letter</label>
      <textarea class="input" name="cover_letter" rows="6" required></textarea>
      <label class="small">Upload resume (optional)</label>
      <input type="file" name="resume" class="input">
      <div style="margin-top:12px"><button class="btn btn-primary">Submit Application</button></div>
    </form>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body></html>