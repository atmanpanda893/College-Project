<?php
require_once __DIR__ . '/../config.php';
if (empty($_SESSION['candidate_id'])) { header('Location: login.php'); exit; }
$id = $_SESSION['candidate_id'];
$stmt = $pdo->prepare('SELECT * FROM candidates WHERE id=?'); $stmt->execute([$id]); $user = $stmt->fetch();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Profile</title><link rel="stylesheet" href="css/style.css"></head><body>
<?php include __DIR__ . '/partials/header.php'; ?>
<div class="container">
  <div class="card fade-in" style="max-width:820px;margin:auto">
    <h2><?php echo htmlspecialchars($user['first_name'].' '.$user['last_name']); ?></h2>
    <div class="small">Email: <?php echo htmlspecialchars($user['email']); ?> | Phone: <?php echo htmlspecialchars($user['phone']); ?></div>
    <p style="margin-top:12px">Skills: <?php echo htmlspecialchars($user['skills'] ?? '—'); ?></p>
    <p><a class="btn btn-primary" href="edit_profile.php">Edit Profile</a></p>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body></html>