<?php
require_once __DIR__ . '/../config.php';
$stmt = $pdo->query('SELECT p.*, c.first_name, c.last_name FROM posts p JOIN candidates c ON p.candidate_id=c.id ORDER BY p.created_at DESC');
$posts = $stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Achievements</title><link rel="stylesheet" href="css/style.css"></head><body>
<?php include __DIR__ . '/partials/header.php'; ?>
<div class="container">
  <h2>Achievements Feed</h2>
  <?php foreach($posts as $p): ?>
    <div class="card fade-in" style="margin-bottom:12px">
      <strong><?php echo htmlspecialchars($p['first_name'].' '.$p['last_name']); ?></strong> <span class="small">• <?php echo htmlspecialchars($p['created_at']); ?></span>
      <h4><?php echo htmlspecialchars($p['title']); ?></h4>
      <div><?php echo nl2br(htmlspecialchars($p['body'])); ?></div>
      <?php if($p['media_path']): ?><div style="margin-top:8px"><a class="small" href="<?php echo $p['media_path']; ?>" target="_blank">Attachment</a></div><?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body></html>