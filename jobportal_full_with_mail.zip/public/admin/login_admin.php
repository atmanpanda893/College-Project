<?php
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../auth/csrf.php';
$err=''; if ($_SERVER['REQUEST_METHOD']==='POST'){ csrf_check(); $email=trim($_POST['email']??''); $pw=$_POST['password']??''; $stmt=$pdo->prepare('SELECT * FROM admins WHERE email=? LIMIT 1'); $stmt->execute([$email]); $a=$stmt->fetch(); if($a && password_verify($pw,$a['password'])){ $_SESSION['is_admin']=true; $_SESSION['admin_id']=$a['id']; header('Location: dashboard_admin.php'); exit;} else $err='Invalid admin credentials'; }
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Login</title><link rel="stylesheet" href="../css/style.css"></head><body>
<?php include __DIR__ . '/../partials/header.php'; ?>
<div class="container"><div class="card" style="max-width:460px;margin:40px auto"><h2>Admin Login</h2><?php if($err): ?><div style="color:#ffbaba"><?php echo $err; ?></div><?php endif; ?><form method="post"><?php echo csrf_field(); ?><input class="input" name="email" placeholder="Admin email" required><input class="input" name="password" placeholder="Password" type="password" required><div style="margin-top:12px"><button class="btn btn-primary">Login</button></div></form></div></div><?php include __DIR__ . '/../partials/footer.php'; ?></body></html>