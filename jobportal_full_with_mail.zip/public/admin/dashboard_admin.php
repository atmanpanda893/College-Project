<?php
require_once __DIR__ . '/../../config.php';
if (empty($_SESSION['is_admin'])) { header('Location: login_admin.php'); exit; }
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Dashboard</title><link rel="stylesheet" href="../css/style.css"></head><body>
<?php include __DIR__ . '/../partials/header.php'; ?>
<div class="container"><div class="card fade-in"><h2>Admin Dashboard</h2><p class="small">Manage companies, jobs and applications</p><div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:12px"><a class="btn btn-primary" href="companies.php">Companies</a><a class="btn btn-ghost" href="jobs_admin.php">Jobs</a><a class="btn btn-ghost" href="applications.php">Applications</a></div></div></div><?php include __DIR__ . '/../partials/footer.php'; ?></body></html>