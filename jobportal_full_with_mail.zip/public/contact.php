<?php require_once __DIR__ . '/../config.php'; include __DIR__ . '/partials/header.php'; ?>
<div class="container"><div class="card"><h2>Contact</h2><p>Instagram: @job_porta.com | Phone: +918260993286 | Email: job_portal@gmail.com</p></div></div>
<?php include __DIR__ . '/partials/footer.php'; ?>