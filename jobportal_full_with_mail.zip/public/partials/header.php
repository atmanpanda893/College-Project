<?php
// header partial - expects config/session loaded
?>
<header class="navbar container fade-in" role="banner">
  <div class="brand">
    <div class="logo">JP</div>
    <div>
      <h1 style="margin:0;font-size:16px">JobPortal</h1>
      <div style="font-size:12px;color:#94a3b8">Find work that fits your skills</div>
    </div>
  </div>

  <nav class="nav-links" aria-label="Main navigation">
    <a href="index.php">Home</a>
    <a href="jobs_list.php">Jobs</a>
    <a href="achievements_feed.php">Feed</a>
    <?php if(!empty($_SESSION['candidate_id'])): ?>
      <a href="profile.php">Profile</a>
      <a href="my_applications.php">Applications</a>
    <?php endif; ?>
  </nav>

  <div style="display:flex; gap:10px; align-items:center;">
    <?php if(empty($_SESSION['candidate_id'])): ?>
      <a class="btn" href="register_candidate.php" style="color:#94a3b8;border:1px solid rgba(255,255,255,0.03);padding:8px 10px;border-radius:8px;">Register</a>
      <a class="btn btn-primary" href="login.php">Sign In</a>
    <?php else: ?>
      <a class="btn" href="post_achievement.php" style="color:#94a3b8;border:1px solid rgba(255,255,255,0.03);padding:8px 10px;border-radius:8px;">Share</a>
      <a class="btn btn-primary" href="logout.php">Logout</a>
    <?php endif; ?>
  </div>
</header>
