<?php
?>
<footer class="site-footer container">
  <div>© <?php echo date('Y'); ?> JobPortal — Built with ❤️</div>
  <div class="small">Instagram: @job_porta.com | Contact: +918260993286 | Email: job_portal@gmail.com</div>
</footer>

<script src="js/theme.js"></script>
<script src="js/ui.js"></script>
