<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth/csrf.php';
$err='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_check();
  $identifier = trim($_POST['identifier']??'');
  $password = $_POST['password']??'';
  $stmt = $pdo->prepare('SELECT * FROM candidates WHERE email=? OR phone=? LIMIT 1');
  $stmt->execute([$identifier,$identifier]);
  $u = $stmt->fetch();
  if ($u && password_verify($password,$u['password'])) {
    $_SESSION['candidate_id']=$u['id'];
    header('Location: dashboard_candidate.php'); exit;
  } else $err='Invalid credentials';
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Login</title><link rel="stylesheet" href="css/style.css"></head><body>
<?php include __DIR__ . '/partials/header.php'; ?>
<div class="container">
  <div class="card fade-in" style="max-width:520px;margin:28px auto">
    <h2>Candidate Login</h2>
    <?php if($err): ?><div style="color:#ffbaba"><?php echo $err; ?></div><?php endif; ?>
    <form method="post">
      <?php echo csrf_field(); ?>
      <label class="small">Email or Mobile</label>
      <input class="input" name="identifier" required>
      <label class="small">Password</label>
      <input class="input" name="password" type="password" required>
      <div style="margin-top:12px"><button class="btn btn-primary">Login</button></div>
    </form>
    <p class="small" style="margin-top:12px">Don't have an account? <a href="register_candidate.php">Register</a></p>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body></html>