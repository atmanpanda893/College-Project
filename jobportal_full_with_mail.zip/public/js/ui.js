document.addEventListener('DOMContentLoaded', function(){
  const els = document.querySelectorAll('.fade-in');
  const obs = new IntersectionObserver((items) => {
    items.forEach(i => {
      if (i.isIntersecting) { i.target.classList.add('show'); obs.unobserve(i.target); }
    });
  }, { threshold: 0.12 });
  els.forEach(e => obs.observe(e));
});