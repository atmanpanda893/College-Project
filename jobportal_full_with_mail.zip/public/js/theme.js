(function(){
  const prefersDark = () => window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  document.addEventListener("DOMContentLoaded", function () {
    const toggle = document.getElementById("themeToggle");
    const toggleSwitch = document.getElementById("themeToggleSwitch");
    const saved = localStorage.getItem("jobportal_theme");
    const applyDark = (isDark) => {
      if (isDark) { document.documentElement.classList.add('dark-mode'); localStorage.setItem('jobportal_theme','dark'); }
      else { document.documentElement.classList.remove('dark-mode'); localStorage.setItem('jobportal_theme','light'); }
    };
    if (saved === 'dark' || (!saved && prefersDark())) { applyDark(true); if (toggle) toggle.textContent='☀ Light'; if (toggleSwitch) toggleSwitch.checked=true; }
    if (toggle) toggle.addEventListener('click', ()=> applyDark(!document.documentElement.classList.contains('dark-mode')));
    if (toggleSwitch) toggleSwitch.addEventListener('change', ()=> applyDark(toggleSwitch.checked));
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e=>{
      if (!localStorage.getItem('jobportal_theme')) applyDark(e.matches);
    });
  });
})();