<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth/mailer.php';
// simple OTP email sender (stores OTP in session)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo 'POST only'; exit; }
$email = trim($_POST['email'] ?? '');
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { echo 'Invalid email'; exit; }
$otp = rand(100000, 999999);
$_SESSION['otp_email'] = $email;
$_SESSION['otp_code'] = $otp;
$_SESSION['otp_expire'] = time() + 300; // 5 minutes
$subject = 'Your JobPortal OTP';
$body = '<p>Your OTP code is: <strong>' . $otp . '</strong></p><p>It expires in 5 minutes.</p>';
$ok = send_email($email, $subject, $body, 'Your OTP code: ' . $otp);
if ($ok) echo 'OTP sent'; else echo 'Failed to send OTP (check mailer setup)';
?>