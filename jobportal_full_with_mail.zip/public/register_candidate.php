<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth/csrf.php';
$err='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_check();
  $first = trim($_POST['first_name']??'');
  $last = trim($_POST['last_name']??'');
  $email = trim($_POST['email']??'');
  $phone = trim($_POST['phone']??'');
  $dob = $_POST['dob']??'';
  $password = $_POST['password']??'';
  if (!$first || !$email || !$phone || !$password) $err='Please fill required fields';
  else {
    $s = $pdo->prepare('SELECT id FROM candidates WHERE email=? OR phone=?');
    $s->execute([$email,$phone]);
    if ($s->fetch()) $err='Email or phone already registered';
    else {
      $hash = password_hash($password,PASSWORD_DEFAULT);
      $stmt = $pdo->prepare('INSERT INTO candidates (first_name,last_name,email,phone,dob,password,created_at) VALUES (?,?,?,?,?,?,NOW())');
      $stmt->execute([$first,$last,$email,$phone,$dob,$hash]);
      header('Location: login.php'); exit;
    }
  }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Register</title><link rel="stylesheet" href="css/style.css"></head><body>
<?php include __DIR__ . '/partials/header.php'; ?>
<div class="container">
  <div class="card fade-in" style="max-width:720px;margin:28px auto">
    <h2>Create an account</h2>
    <?php if($err): ?><div style="color:#ffbaba"><?php echo $err; ?></div><?php endif; ?>
    <form method="post">
      <?php echo csrf_field(); ?>
      <div style="display:flex;gap:8px">
        <input class="input" name="first_name" placeholder="First name" required>
        <input class="input" name="last_name" placeholder="Last name">
      </div>
      <div style="display:flex;gap:8px;margin-top:8px">
        <input class="input" name="email" placeholder="Email" type="email" required>
        <input class="input" name="phone" placeholder="Phone" required>
      </div>
      <div style="display:flex;gap:8px;margin-top:8px">
        <input class="input" name="dob" type="date">
        <input class="input" name="password" type="password" placeholder="Password" required>
      </div>
      <div style="margin-top:12px"><label><input type="checkbox" name="terms" required> I agree to terms & conditions</label></div>
      <div style="margin-top:12px"><button class="btn btn-primary">Register</button></div>
    </form>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body></html>