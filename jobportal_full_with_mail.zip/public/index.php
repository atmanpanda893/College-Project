<?php
require_once __DIR__ . '/../config.php';
?>
<!doctype html><html><head><meta charset="utf-8"><title>JobPortal - Home</title><link rel="stylesheet" href="css/style.css"></head><body>
<?php include __DIR__ . '/partials/header.php'; ?>
<div class="container">
  <section class="card fade-in">
    <h2>Find your dream job — matched to your skills</h2>
    <p class="small">Create a profile, post achievements, and apply directly.</p>
    <div style="margin-top:14px">
      <a class="btn btn-primary" href="jobs_list.php">Browse Jobs</a>
      <a class="btn" href="register_candidate.php" style="margin-left:8px;">Get Started</a>
    </div>
  </section>

  <section style="margin-top:18px">
    <h3>Latest Jobs</h3>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px">
      <?php
      $stmt = $pdo->query('SELECT j.*, c.company_name FROM jobs j JOIN companies c ON j.company_id=c.id ORDER BY j.created_at DESC LIMIT 6');
      while($job = $stmt->fetch()):
      ?>
      <div class="card fade-in">
        <h3><?php echo htmlspecialchars($job['title']); ?></h3>
        <div class="small"><?php echo htmlspecialchars($job['company_name']); ?> • <?php echo htmlspecialchars($job['location']); ?></div>
        <p class="small"><?php echo htmlspecialchars(substr($job['description'],0,120)); ?>…</p>
        <div style="margin-top:10px"><a class="btn btn-primary" href="job_details.php?id=<?php echo $job['id']; ?>">Apply</a></div>
      </div>
      <?php endwhile; ?>
    </div>
  </section>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body></html>