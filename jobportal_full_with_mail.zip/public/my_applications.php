<?php
require_once __DIR__ . '/../config.php';
if (empty($_SESSION['candidate_id'])) { header('Location: login.php'); exit; }
$cand = $_SESSION['candidate_id'];
$stmt = $pdo->prepare('SELECT a.*, j.title, c.company_name FROM applications a JOIN jobs j ON a.job_id=j.id JOIN companies c ON j.company_id=c.id WHERE a.candidate_id=? ORDER BY a.applied_at DESC');
$stmt->execute([$cand]); $apps = $stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>My Applications</title><link rel="stylesheet" href="css/style.css"></head><body>
<?php include __DIR__ . '/partials/header.php'; ?>
<div class="container">
  <div class="card fade-in">
    <h2>My Applications</h2>
    <?php foreach($apps as $a): ?>
      <div style="border:1px solid rgba(255,255,255,0.03);padding:10px;margin:8px 0;border-radius:8px">
        <strong><?php echo htmlspecialchars($a['title']); ?></strong> — <?php echo htmlspecialchars($a['company_name']); ?><br>
        UID: <?php echo htmlspecialchars($a['application_uid']); ?> | Status: <?php echo htmlspecialchars($a['status'] ?? 'applied'); ?> | Applied: <?php echo htmlspecialchars($a['applied_at']); ?>
        <?php if($a['resume_path']): ?> | <a class="small" href="<?php echo $a['resume_path']; ?>" target="_blank">Resume</a><?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body></html>