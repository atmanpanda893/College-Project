<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth/csrf.php';
if (empty($_SESSION['candidate_id'])) { header('Location: login.php'); exit; }
$id = $_SESSION['candidate_id'];
$stmt = $pdo->prepare('SELECT * FROM candidates WHERE id=?'); $stmt->execute([$id]); $user = $stmt->fetch();
$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_check();
  $skills = trim($_POST['skills'] ?? '');
  $about = trim($_POST['about'] ?? '');
  $resume_path = $user['resume_path'] ?? null;
  if (!empty($_FILES['resume']['name'])) {
    $u = __DIR__ . '/../uploads';
    if (!is_dir($u)) mkdir($u,0777,true);
    $name = time().'_'.basename($_FILES['resume']['name']);
    move_uploaded_file($_FILES['resume']['tmp_name'],$u.'/'.$name);
    $resume_path = 'uploads/'.$name;
  }
  $stmt = $pdo->prepare('UPDATE candidates SET skills=?, about=?, resume_path=? WHERE id=?');
  $stmt->execute([$skills,$about,$resume_path,$id]);
  $msg='Profile updated';
  $stmt = $pdo->prepare('SELECT * FROM candidates WHERE id=?'); $stmt->execute([$id]); $user = $stmt->fetch();
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Edit Profile</title><link rel="stylesheet" href="css/style.css"></head><body>
<?php include __DIR__ . '/partials/header.php'; ?>
<div class="container">
  <div class="card fade-in" style="max-width:720px;margin:auto">
    <h2>Edit Profile</h2>
    <?php if($msg): ?><div style="color:lightgreen"><?php echo $msg; ?></div><?php endif; ?>
    <form method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <label class="small">Skills (comma separated)</label>
      <input class="input" name="skills" value="<?php echo htmlspecialchars($user['skills'] ?? ''); ?>">
      <label class="small">About</label>
      <textarea class="input" name="about" rows="6"><?php echo htmlspecialchars($user['about'] ?? ''); ?></textarea>
      <label class="small">Upload resume (PDF/DOC)</label>
      <input type="file" name="resume" class="input">
      <div style="margin-top:12px"><button class="btn btn-primary">Save</button></div>
    </form>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body></html>