<?php
require_once __DIR__ . '/../config.php';
if (!isset($_GET['id'])) { header('Location: jobs_list.php'); exit; }
$id = intval($_GET['id']);
$stmt = $pdo->prepare('SELECT j.*, c.company_name FROM jobs j JOIN companies c ON j.company_id=c.id WHERE j.id=?');
$stmt->execute([$id]); $job = $stmt->fetch();
if (!$job) { echo 'Job not found'; exit; }
?>
<!doctype html><html><head><meta charset="utf-8"><title><?php echo htmlspecialchars($job['title']); ?></title><link rel="stylesheet" href="css/style.css"></head><body>
<?php include __DIR__ . '/partials/header.php'; ?>
<div class="container">
  <div class="card fade-in">
    <h2><?php echo htmlspecialchars($job['title']); ?></h2>
    <div class="small"><?php echo htmlspecialchars($job['company_name']); ?> • <?php echo htmlspecialchars($job['location']); ?></div>
    <div style="margin-top:12px"><?php echo nl2br(htmlspecialchars($job['description'])); ?></div>
    <div style="margin-top:12px">
      <?php if(isset($_SESSION['candidate_id'])): ?>
        <a class="btn btn-primary" href="apply_job.php?id=<?php echo $job['id']; ?>">Apply</a>
      <?php else: ?>
        <a class="btn btn-primary" href="login.php">Login to Apply</a>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body></html>