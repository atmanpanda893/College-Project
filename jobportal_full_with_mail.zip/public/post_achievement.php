<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth/csrf.php';
if (empty($_SESSION['candidate_id'])) { header('Location: login.php'); exit; }
$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_check();
  $title = trim($_POST['title'] ?? '');
  $body = trim($_POST['body'] ?? '');
  $media_path = null;
  if (!empty($_FILES['media']['name'])) {
    $u = __DIR__ . '/../uploads';
    if (!is_dir($u)) mkdir($u,0777,true);
    $name = time().'_'.basename($_FILES['media']['name']);
    move_uploaded_file($_FILES['media']['tmp_name'],$u.'/'.$name);
    $media_path = 'uploads/'.$name;
  }
  $stmt = $pdo->prepare('INSERT INTO posts (candidate_id,title,body,media_path,created_at) VALUES (?,?,?,?,NOW())');
  $stmt->execute([$_SESSION['candidate_id'],$title,$body,$media_path]);
  $msg='Posted';
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Share Achievement</title><link rel="stylesheet" href="css/style.css"></head><body>
<?php include __DIR__ . '/partials/header.php'; ?>
<div class="container">
  <div class="card fade-in" style="max-width:720px;margin:auto">
    <h2>Share Achievement</h2>
    <?php if($msg): ?><div style="color:lightgreen"><?php echo $msg; ?></div><?php endif; ?>
    <form method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <input class="input" name="title" placeholder="Title" required>
      <textarea class="input" name="body" rows="6" placeholder="Describe your achievement" required></textarea>
      <label class="small">Attachment (optional)</label>
      <input type="file" name="media" class="input">
      <div style="margin-top:12px"><button class="btn btn-primary">Post</button></div>
    </form>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body></html>