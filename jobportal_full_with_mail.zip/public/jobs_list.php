<?php
require_once __DIR__ . '/../config.php';
$skill = trim($_GET['skill'] ?? '');
$loc = trim($_GET['location'] ?? '');
$sql = 'SELECT j.*, c.company_name FROM jobs j JOIN companies c ON j.company_id=c.id WHERE 1=1';
$params=[];
if($skill){ $sql .= ' AND j.required_skills LIKE ?'; $params[]="%$skill%"; }
if($loc){ $sql .= ' AND j.location LIKE ?'; $params[]="%$loc%"; }
$sql .= ' ORDER BY j.created_at DESC';
$stmt = $pdo->prepare($sql); $stmt->execute($params); $jobs = $stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Jobs</title><link rel="stylesheet" href="css/style.css"></head><body>
<?php include __DIR__ . '/partials/header.php'; ?>
<div class="container">
  <div class="card fade-in">
    <h2>Search Jobs</h2>
    <form method="get" style="display:flex;gap:8px">
      <input class="input" name="skill" placeholder="Skill" value="<?php echo htmlspecialchars($skill); ?>">
      <input class="input" name="location" placeholder="Location" value="<?php echo htmlspecialchars($loc); ?>">
      <button class="btn btn-primary">Search</button>
    </form>
  </div>
  <div style="margin-top:16px;display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px">
    <?php if(empty($jobs)): ?>
      <div class="card">No jobs found.</div>
    <?php else: foreach($jobs as $job): ?>
      <div class="card fade-in">
        <h3><?php echo htmlspecialchars($job['title']); ?></h3>
        <div class="small"><?php echo htmlspecialchars($job['company_name']); ?> • <?php echo htmlspecialchars($job['location']); ?></div>
        <p class="small"><?php echo htmlspecialchars(substr($job['description'],0,120)); ?>…</p>
        <div style="margin-top:10px"><a class="btn btn-primary" href="job_details.php?id=<?php echo $job['id']; ?>">View</a></div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body></html>