<?php
require_once __DIR__ . '/../config.php';
if (empty($_SESSION['candidate_id'])) { header('Location: login.php'); exit; }
$stmt = $pdo->prepare('SELECT first_name FROM candidates WHERE id=?'); $stmt->execute([$_SESSION['candidate_id']]); $user = $stmt->fetch();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Dashboard</title><link rel="stylesheet" href="css/style.css"></head><body>
<?php include __DIR__ . '/partials/header.php'; ?>
<div class="container">
  <div class="card fade-in">
    <h2>Welcome, <?php echo htmlspecialchars($user['first_name']); ?></h2>
    <p class="small">Your suggested jobs and activity.</p>
    <p><a class="btn btn-primary" href="jobs_list.php">Browse Jobs</a> <a class="btn" href="post_achievement.php">Share Achievement</a></p>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body></html>