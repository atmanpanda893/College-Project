<?php
require_once __DIR__ . '/../config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo 'POST only'; exit; }
$email = trim($_POST['email'] ?? '');
$code = trim($_POST['otp'] ?? '');
if (empty($_SESSION['otp_code']) || empty($_SESSION['otp_email'])) { echo 'No OTP sent'; exit; }
if ($email !== $_SESSION['otp_email']) { echo 'Email mismatch'; exit; }
if (time() > ($_SESSION['otp_expire'] ?? 0)) { echo 'OTP expired'; exit; }
if ($code == $_SESSION['otp_code']) {
    // mark verified (you can use this to allow login/registration)
    unset($_SESSION['otp_code'], $_SESSION['otp_email'], $_SESSION['otp_expire']);
    echo 'OTP verified';
} else echo 'Invalid OTP';
?>