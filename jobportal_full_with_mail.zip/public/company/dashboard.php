<?php
require_once __DIR__ . '/../../config.php';
if (empty($_SESSION['company_id'])) { header('Location: login.php'); exit; }
$stmt = $pdo->prepare('SELECT * FROM companies WHERE id=?'); $stmt->execute([$_SESSION['company_id']]); $company=$stmt->fetch();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Company Dashboard</title><link rel="stylesheet" href="../css/style.css"></head><body><?php include __DIR__ . '/../partials/header.php'; ?><div class="container"><div class="card fade-in"><h2><?php echo htmlspecialchars($company['company_name']); ?></h2><p class="small">Post jobs, view applicants and schedule interviews</p><div style="margin-top:12px"><a class="btn btn-primary" href="create_job.php">Create Job</a><a class="btn btn-ghost" href="applicants.php">Applicants</a></div></div></div><?php include __DIR__ . '/../partials/footer.php'; ?></body></html>