
JobPortal Full Project (demo)
----------------------------
Steps to run locally (XAMPP):
1. Extract this folder to C:\xampp\htdocs\jobportal_full (or similar)
2. Import sql/db.sql into phpMyAdmin to create the database and tables.
3. Optionally import sql/sample_data.sql for sample companies/jobs.
4. Update config.php with your DB credentials and SMTP settings.
5. Run 'composer require phpmailer/phpmailer' in the project root to install PHPMailer.
   (Composer required: https://getcomposer.org/)
6. Ensure uploads/ is writable.
7. Visit http://localhost/jobportal_full/public/ to open the site.

OTP / Email:
- send_otp.php: POST { email } to send an OTP (uses PHPMailer if installed, otherwise PHP mail())
- verify_otp.php: POST { email, otp } to verify
