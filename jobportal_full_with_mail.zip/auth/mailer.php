<?php
// mailer.php - wrapper to send email using PHPMailer if available, otherwise provide instructions.
require_once __DIR__ . '/../config.php';

function send_email($to, $subject, $htmlBody, $altBody = ''){
    // Try to use Composer's PHPMailer if installed
    $vendor = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($vendor)) {
        require $vendor;
        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
        try {
            global $smtp;
            // Server settings
            $mail->isSMTP();
            $mail->Host = $smtp['host'];
            $mail->SMTPAuth = true;
            $mail->Username = $smtp['username'];
            $mail->Password = $smtp['password'];
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = $smtp['port'];
            $mail->setFrom($smtp['from'], $smtp['from_name']);
            $mail->addAddress($to);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $htmlBody;
            $mail->AltBody = $altBody;
            $mail->send();
            return true;
        } catch (Exception $e) {
            error_log('Mailer error: ' . $mail->ErrorInfo);
            return false;
        }
    } else {
        // PHPMailer not installed — try PHP mail() as fallback (may need sendmail setup on Windows)
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= 'From: ' . htmlentities($GLOBALS['smtp']['from_name']) . ' <' . htmlentities($GLOBALS['smtp']['from']) . '>' . "\r\n";
        $result = mail($to, $subject, $htmlBody, $headers);
        if ($result) return true;
        // if mail() failed, give actionable message in logs
        error_log('send_email: PHPMailer not found (run composer require phpmailer/phpmailer) and PHP mail() failed.');
        return false;
    }
}
?>