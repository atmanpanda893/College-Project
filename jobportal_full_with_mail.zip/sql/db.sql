-- SQL schema (simplified)
CREATE DATABASE IF NOT EXISTS job_portal_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE job_portal_db;

CREATE TABLE IF NOT EXISTS candidates (
  id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(120),
  last_name VARCHAR(120),
  email VARCHAR(255) UNIQUE,
  phone VARCHAR(50) UNIQUE,
  dob DATE,
  password VARCHAR(255),
  skills TEXT,
  about TEXT,
  resume_path VARCHAR(255),
  created_at DATETIME
);

CREATE TABLE IF NOT EXISTS companies (
  id INT AUTO_INCREMENT PRIMARY KEY,
  company_name VARCHAR(255),
  email VARCHAR(255),
  password VARCHAR(255),
  address TEXT,
  details TEXT,
  created_at DATETIME
);

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255),
  password VARCHAR(255),
  created_at DATETIME
);

CREATE TABLE IF NOT EXISTS jobs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  company_id INT,
  title VARCHAR(255),
  description TEXT,
  required_skills VARCHAR(255),
  location VARCHAR(255),
  job_type VARCHAR(50),
  salary_min INT,
  salary_max INT,
  experience_years INT,
  created_at DATETIME,
  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_uid VARCHAR(64),
  candidate_id INT,
  job_id INT,
  cover_letter TEXT,
  resume_path VARCHAR(255),
  status VARCHAR(50) DEFAULT 'applied',
  viewed_by_company TINYINT(1) DEFAULT 0,
  shortlisted TINYINT(1) DEFAULT 0,
  applied_at DATETIME,
  applied_ip VARCHAR(45),
  FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE,
  FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS posts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  candidate_id INT,
  title VARCHAR(255),
  body TEXT,
  media_path VARCHAR(255),
  created_at DATETIME,
  FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE
);
