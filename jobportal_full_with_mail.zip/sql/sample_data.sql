-- Sample data for JobPortal
USE job_portal_db;

-- Sample companies
INSERT INTO companies (company_name, email, password, address, details, created_at) VALUES
('Acme Solutions','hr@acme.test','', 'Bargarh, Odisha', 'A software company', NOW()),
('TechNova','contact@technova.test','', 'Bhubaneswar, Odisha', 'AI & Cloud services', NOW());

-- Sample jobs
INSERT INTO jobs (company_id, title, description, required_skills, location, job_type, salary_min, salary_max, experience_years, created_at) VALUES
(1, 'Junior PHP Developer', 'We are hiring a junior PHP developer to join our web team. Knowledge of MySQL required.', 'PHP,MySQL,HTML,CSS', 'Bargarh,Odisha', 'Full-time', 15000, 25000, 0, NOW()),
(2, 'Frontend Engineer', 'Looking for a frontend engineer experienced with modern JS frameworks and responsive UI.', 'JavaScript,HTML,CSS,React', 'Bhubaneswar,Odisha', 'Full-time', 25000, 45000, 1, NOW());
